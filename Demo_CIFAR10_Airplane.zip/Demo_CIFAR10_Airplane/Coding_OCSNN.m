%%% This file is to reproduce the results of Table IV
%%% OC-SNN on MNIST-2 dataset: G-mean=94.5


clear all;

N_ensub=500; % No. of neurons in the En-SNN subnet
N_exsub=300; % No. of neurons in the Ex-SNN subnet

%% [1] Reproduce the result in Table IV

C1 = 10.^-4;
ACCA_b=My_Demo(C1, N_ensub, N_exsub, 1);
ACCA_b

%% [2] Grid Search
for ii=1:11
    C1 = 10 .^ [-5 -4 -3 -2 -1 0 1 2 3 4 5];
    ACCA(ii)=My_Demo(C1(ii), N_ensub, N_exsub, 1);
end
ACCA