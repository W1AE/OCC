%%% This file is to reproduce the results of Table IV
%%% MCOC-SNN on MNIST-2 dataset: G-mean=94.8


clear all;

N_ensub=500; % No. of neurons in the En-SNN subnet
N_exsub=300; % No. of neurons in the Ex-SNN subnet
K=50;   % Maximum iteration of MCC
epsilon=0.0001; % the tolerant error

%% [1] Reproduce the result in Table IV

C1 = 10.^-2;
sigma=[5];    % Gaussian kernel bandwidth
ACCA_b=My_Demo_mcc(C1, N_ensub, N_exsub, K, epsilon, sigma, 1);
ACCA_b

%% [2] Grid Search
for ii=1:11
    C1 = 10 .^ [-5 -4 -3 -2 -1 0 1 2 3 4 5];
    for jj=1:5
        sigma=[0.1 1 2 3 5];
        ACCA(ii,jj)=My_Demo_mcc(C1(ii), N_ensub, N_exsub, K, epsilon, sigma(jj), 1);
    end
end
ACCA